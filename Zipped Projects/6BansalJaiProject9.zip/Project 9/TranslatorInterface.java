public interface TranslatorInterface {
    public boolean isVowel(String s);
    public String translateE2P(String s);
    public String translateP2E(String s);
}